﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exam.Model
{
    public class User
    {
        public User(string fullName, string info)
        {
            FullName = fullName;
            Info = info;
        }

        public string FullName { get; set; }
        public string Info { get; set; }
    }
}
